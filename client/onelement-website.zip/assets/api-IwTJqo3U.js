const e="https://api.onelement.in/api".replace(/\/$/,"");export{e as A};
